import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

export default function RedesSocialesPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-background to-secondary/30">
        <div className="container-custom text-center">
          <h1 className="section-title mb-6">Gestión Profesional de Redes Sociales</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-10">
            Potencia tu presencia digital con nuestros servicios de gestión de redes sociales. Creamos, programamos y
            analizamos contenido estratégico para tu marca.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/contacto">
              <Button variant="buq" size="buq">
                Contactar Ahora
              </Button>
            </Link>
            <Link href="#paquetes">
              <Button variant="outline" size="buq">
                Ver Paquetes
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Servicios */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="section-title mb-6">Nuestros Servicios</h2>
            <p className="text-lg text-muted-foreground">
              Ofrecemos soluciones completas para gestionar tus redes sociales de forma profesional y efectiva
            </p>
          </div>

          <div className="card-container">
            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Creación de Contenido</h3>
              <p className="text-muted-foreground flex-grow flex items-center">
                Diseñamos y creamos contenido relevante y atractivo adaptado a cada plataforma y a tu audiencia
                objetivo.
              </p>
              <Button variant="buq" size="buq" className="w-full mt-6">
                Contratar
              </Button>
            </div>

            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                  <line x1="16" y1="2" x2="16" y2="6" />
                  <line x1="8" y1="2" x2="8" y2="6" />
                  <line x1="3" y1="10" x2="21" y2="10" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Planificación y Programación</h3>
              <p className="text-muted-foreground flex-grow flex items-center">
                Desarrollamos calendarios de contenido y programamos publicaciones para mantener una presencia
                consistente.
              </p>
              <Button variant="buq" size="buq" className="w-full mt-6">
                Contratar
              </Button>
            </div>

            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Análisis y Reportes</h3>
              <p className="text-muted-foreground flex-grow flex items-center">
                Monitorizamos el rendimiento de tus redes sociales y proporcionamos informes detallados con métricas
                clave.
              </p>
              <Button variant="buq" size="buq" className="w-full mt-6">
                Contratar
              </Button>
            </div>

            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="10" />
                  <path d="M8 14s1.5 2 4 2 4-2 4-2" />
                  <line x1="9" y1="9" x2="9.01" y2="9" />
                  <line x1="15" y1="9" x2="15.01" y2="9" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Community Management</h3>
              <p className="text-muted-foreground flex-grow flex items-center">
                Gestionamos la comunidad online, respondiendo comentarios y mensajes para mantener una buena relación
                con tus seguidores.
              </p>
              <Button variant="buq" size="buq" className="w-full mt-6">
                Contratar
              </Button>
            </div>

            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34" />
                  <polygon points="18 2 22 6 12 16 8 16 8 12 18 2" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Diseño Gráfico</h3>
              <p className="text-muted-foreground flex-grow flex items-center">
                Creamos diseños personalizados para tus publicaciones, manteniendo la coherencia visual de tu marca.
              </p>
              <Button variant="buq" size="buq" className="w-full mt-6">
                Contratar
              </Button>
            </div>

            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 20h9" />
                  <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Estrategia Digital</h3>
              <p className="text-muted-foreground flex-grow flex items-center">
                Desarrollamos estrategias personalizadas para cada plataforma, alineadas con tus objetivos de negocio.
              </p>
              <Button variant="buq" size="buq" className="w-full mt-6">
                Contratar
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Paquetes de Precios */}
      <section id="paquetes" className="py-16 md:py-24 bg-secondary/30">
        <div className="container-custom">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="section-title mb-6">Nuestros Paquetes</h2>
            <p className="text-lg text-muted-foreground">
              Elige el plan que mejor se adapte a las necesidades de tu negocio
            </p>
          </div>

          <div className="card-container">
            {/* Paquete Trimestral */}
            <div className="card-item bg-card rounded-xl border shadow-sm overflow-hidden flex flex-col">
              <div className="p-6 bg-primary/5">
                <h3 className="text-xl font-bold mb-2">Paquete Trimestral</h3>
                <p className="text-muted-foreground mb-4">Ideal para probar nuestros servicios</p>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold">$3,999</span>
                  <span className="text-muted-foreground ml-2">/ mes</span>
                </div>
                <p className="text-sm text-muted-foreground">Compromiso de 3 meses</p>
              </div>

              <div className="p-6 flex flex-col flex-grow">
                <ul className="space-y-3 flex-grow">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>12 publicaciones mensuales</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Diseño gráfico personalizado</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Gestión de 2 redes sociales</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Reporte mensual de resultados</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Respuesta a comentarios y mensajes</span>
                  </li>
                </ul>

                <Link href="/contacto?plan=trimestral" className="block mt-6">
                  <Button variant="buq" size="buq" className="w-full">
                    Contratar Plan
                  </Button>
                </Link>
              </div>
            </div>

            {/* Paquete Semestral */}
            <div className="card-item bg-card rounded-xl border shadow-lg overflow-hidden relative flex flex-col">
              <div className="absolute top-5 right-5 bg-primary text-white text-xs font-bold py-1 px-3 rounded-full">
                Popular
              </div>

              <div className="p-6 bg-primary/10">
                <h3 className="text-xl font-bold mb-2">Paquete Semestral</h3>
                <p className="text-muted-foreground mb-4">Balance perfecto de precio y beneficios</p>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold">$3,499</span>
                  <span className="text-muted-foreground ml-2">/ mes</span>
                </div>
                <p className="text-sm text-muted-foreground">Compromiso de 6 meses</p>
              </div>

              <div className="p-6 flex flex-col flex-grow">
                <ul className="space-y-3 flex-grow">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>16 publicaciones mensuales</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Diseño gráfico personalizado</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Gestión de 3 redes sociales</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Reportes quincenales de resultados</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Respuesta a comentarios y mensajes</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>1 campaña de anuncios básica</span>
                  </li>
                </ul>

                <Link href="/contacto?plan=semestral" className="block mt-6">
                  <Button variant="buq" size="buq" className="w-full">
                    Contratar Plan
                  </Button>
                </Link>
              </div>
            </div>

            {/* Paquete Anual */}
            <div className="card-item bg-card rounded-xl border shadow-sm overflow-hidden flex flex-col">
              <div className="p-6 bg-primary/5">
                <h3 className="text-xl font-bold mb-2">Paquete Anual</h3>
                <p className="text-muted-foreground mb-4">Máximo valor y beneficios</p>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold">$2,999</span>
                  <span className="text-muted-foreground ml-2">/ mes</span>
                </div>
                <p className="text-sm text-muted-foreground">Compromiso de 12 meses</p>
              </div>

              <div className="p-6 flex flex-col flex-grow">
                <ul className="space-y-3 flex-grow">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>20 publicaciones mensuales</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Diseño gráfico premium</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Gestión de 4 redes sociales</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Reportes semanales de resultados</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Respuesta a comentarios 24/7</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>2 campañas de anuncios mensuales</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Estrategia de crecimiento personalizada</span>
                  </li>
                </ul>

                <Link href="/contacto?plan=anual" className="block mt-6">
                  <Button variant="buq" size="buq" className="w-full">
                    Contratar Plan
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 max-w-2xl mx-auto">
            ¿Listo para potenciar tu presencia en redes sociales?
          </h2>
          <p className="text-lg mb-8 max-w-3xl mx-auto opacity-90">
            Agenda una llamada con nuestros expertos para analizar tus necesidades y encontrar la mejor solución para tu
            negocio.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/contacto">
              <Button className="bg-white text-primary hover:bg-white/90" size="buq">
                Contactar Ahora
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}

