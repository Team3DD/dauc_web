"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { ChevronDown, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isProductDropdownOpen, setIsProductDropdownOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const dropdownRef = useRef(null)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsProductDropdownOpen(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    document.addEventListener("mousedown", handleClickOutside)

    return () => {
      window.removeEventListener("scroll", handleScroll)
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  return (
    <header
      className={`sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 transition-all duration-300 ${isScrolled ? "shadow-md" : ""}`}
    >
      <div className="container-custom flex h-16 items-center justify-between">
        <div className="flex items-center">
          <Link href="/" className="mr-6">
            <div className="w-24 h-10 flex items-center">
              <span className="dune-text text-2xl">DAUC</span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center space-x-6">
            <div className="relative" ref={dropdownRef}>
              <button
                className="flex items-center gap-1.5 text-foreground hover:text-primary transition-colors"
                onClick={() => setIsProductDropdownOpen(!isProductDropdownOpen)}
              >
                Producto{" "}
                <ChevronDown
                  className={`h-4 w-4 transition-transform duration-200 ${isProductDropdownOpen ? "rotate-180" : ""}`}
                />
              </button>

              {isProductDropdownOpen && (
                <div className="absolute top-full mt-2 w-56 rounded-md border bg-popover p-2 shadow-md">
                  <Link
                    href="/paginas-web"
                    className="block rounded px-3 py-2 hover:bg-accent hover:text-accent-foreground"
                  >
                    Páginas Web
                  </Link>
                  <Link
                    href="/e-commerce"
                    className="block rounded px-3 py-2 hover:bg-accent hover:text-accent-foreground"
                  >
                    E-Commerce
                  </Link>
                  <Link href="/apps" className="block rounded px-3 py-2 hover:bg-accent hover:text-accent-foreground">
                    Apps
                  </Link>
                  <Link
                    href="/redes-sociales"
                    className="block rounded px-3 py-2 hover:bg-accent hover:text-accent-foreground"
                  >
                    Redes Sociales
                  </Link>
                </div>
              )}
            </div>

            <Link href="/precios" className="text-foreground hover:text-primary transition-colors">
              Precios
            </Link>

            <Link href="/soporte" className="text-foreground hover:text-primary transition-colors">
              Soporte
            </Link>

            <Link href="/tips" className="text-foreground hover:text-primary transition-colors">
              Tips
            </Link>

            <Link href="/noticias" className="text-foreground hover:text-primary transition-colors">
              Noticias
            </Link>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-4">
            <Link href="/mi-cuenta" className="text-foreground hover:text-primary transition-colors">
              Mi Cuenta
            </Link>

            <Link href="/empezar">
              <Button variant="buq" size="buq">
                ¡Empezar Ahora!
              </Button>
            </Link>
          </div>

          <ThemeToggle />

          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden py-4 px-4 bg-background border-t">
          <nav className="flex flex-col space-y-4">
            <button
              className="flex items-center justify-between w-full py-2 text-left"
              onClick={() => setIsProductDropdownOpen(!isProductDropdownOpen)}
            >
              <span>Producto</span>
              <ChevronDown className={`h-4 w-4 transition-transform ${isProductDropdownOpen ? "rotate-180" : ""}`} />
            </button>

            {isProductDropdownOpen && (
              <div className="pl-4 flex flex-col space-y-2">
                <Link href="/paginas-web" className="py-1">
                  Páginas Web
                </Link>
                <Link href="/e-commerce" className="py-1">
                  E-Commerce
                </Link>
                <Link href="/apps" className="py-1">
                  Apps
                </Link>
                <Link href="/redes-sociales" className="py-1">
                  Redes Sociales
                </Link>
              </div>
            )}

            <Link href="/precios" className="py-2">
              Precios
            </Link>

            <Link href="/soporte" className="py-2">
              Soporte
            </Link>

            <Link href="/tips" className="py-2">
              Tips
            </Link>

            <Link href="/noticias" className="py-2">
              Noticias
            </Link>

            <Link href="/mi-cuenta" className="py-2">
              Mi Cuenta
            </Link>

            <Link href="/empezar" className="w-full">
              <Button variant="buq" size="buq" className="w-full">
                ¡Empezar Ahora!
              </Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}

