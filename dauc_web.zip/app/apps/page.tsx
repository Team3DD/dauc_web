import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Clock } from "lucide-react"

export default function AppsPage() {
  return (
    <section className="py-24 md:py-32">
      <div className="container-custom text-center">
        <div className="max-w-3xl mx-auto">
          <h1 className="section-title mb-6">Desarrollo de Apps</h1>
          <div className="relative w-24 h-24 mx-auto mb-8">
            <Clock className="w-24 h-24 text-primary animate-pulse" />
          </div>
          <p className="text-2xl font-medium mb-4">Próximamente</p>
          <p className="text-lg text-muted-foreground mb-8">
            Estamos trabajando en nuestros servicios de desarrollo de aplicaciones móviles y web. Pronto podrás
            disfrutar de soluciones personalizadas para tu negocio.
          </p>
          <p className="text-lg mb-8">¿Tienes un proyecto en mente? Contáctanos y podemos discutir tus necesidades.</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/contacto">
              <Button variant="buq" size="buq">
                Contactar
              </Button>
            </Link>
            <Link href="/">
              <Button variant="outline" size="buq">
                Volver al inicio
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

