import Image from "next/image"
import Link from "next/link"
import { Calendar, Monitor, Users, Video } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <>
      {/* Hero Section */}
      <section className="py-12 md:py-20">
        <div className="container-custom grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-block px-4 py-2 bg-secondary rounded-full mb-6">
              <p className="text-sm font-medium">Bienvenid@ a DAUC</p>
            </div>
            <h1 className="section-title mb-6">
              Queremos ser <br />
              tu socio digital
            </h1>
            <p className="text-lg mb-6">
              Digitaliza tu negocio con <span className="font-semibold">DAUC</span>, construimos juntos tu{" "}
              <span className="font-semibold">Página o App web</span>, de lo que quieras. E-commerce, sistema de
              suscripciones, reservaciones, portfolio o ¡lo que quieras!
            </p>
            <p className="text-lg mb-8 font-medium">¿Estás listo para tener tu propia plataforma digital?</p>
            <div className="flex flex-wrap gap-4">
              <Link href="/empezar">
                <Button variant="buq" size="buq">
                  ¡Empezar Ahora!
                </Button>
              </Link>
              <Link href="/demo">
                <Button variant="buqOutline" size="buq">
                  Agendar Demo
                </Button>
              </Link>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 h-[500px] relative">
            <div className="col-span-2 h-full relative rounded-3xl overflow-hidden">
              <Image
                src="/images/professional-1.jpg"
                alt="Profesional de DAUC"
                width={400}
                height={600}
                className="w-full h-full object-cover"
              />
              <div className="absolute right-4 top-4 p-3 bg-primary rounded-full">
                <Video className="h-5 w-5 text-white" />
              </div>
            </div>

            <div className="col-span-1 grid grid-rows-2 gap-4 h-full">
              <div className="relative rounded-3xl overflow-hidden">
                <Image
                  src="/images/professional-2.jpg"
                  alt="Profesional de DAUC"
                  width={200}
                  height={300}
                  className="w-full h-full object-cover"
                />
                <div className="absolute right-4 top-4 p-3 bg-primary rounded-full">
                  <Users className="h-5 w-5 text-white" />
                </div>
              </div>

              <div className="relative rounded-3xl overflow-hidden">
                <Image
                  src="/images/professional-3.jpg"
                  alt="Profesional de DAUC"
                  width={200}
                  height={300}
                  className="w-full h-full object-cover"
                />
                <div className="absolute right-4 top-4 p-3 bg-primary rounded-full">
                  <Monitor className="h-5 w-5 text-white" />
                </div>
              </div>
            </div>

            <div className="absolute bottom-10 -left-6 p-3 bg-primary rounded-full">
              <Calendar className="h-5 w-5 text-white" />
            </div>
          </div>
        </div>
      </section>

      {/* Clients Section */}
      <section className="py-12 bg-secondary/50 dark:bg-secondary/20">
        <div className="container-custom">
          <p className="text-center text-lg text-foreground/80 mb-10">Algunos de nuestros socios, ¡muchas gracias!</p>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 items-center justify-items-center">
            <div className="w-32 h-12 relative grayscale hover:grayscale-0 transition-all duration-300">
              <Image
                src="/images/partner-1.png"
                alt="Socio 1"
                width={128}
                height={48}
                className="w-full h-full object-contain"
              />
            </div>
            <div className="w-32 h-12 relative grayscale hover:grayscale-0 transition-all duration-300">
              <Image
                src="/images/partner-2.png"
                alt="Socio 2"
                width={128}
                height={48}
                className="w-full h-full object-contain"
              />
            </div>
            <div className="w-32 h-12 relative grayscale hover:grayscale-0 transition-all duration-300">
              <Image
                src="/images/partner-3.png"
                alt="Socio 3"
                width={128}
                height={48}
                className="w-full h-full object-contain"
              />
            </div>
            <div className="w-32 h-12 relative grayscale hover:grayscale-0 transition-all duration-300">
              <Image
                src="/images/partner-4.png"
                alt="Socio 4"
                width={128}
                height={48}
                className="w-full h-full object-contain"
              />
            </div>
            <div className="w-32 h-12 relative grayscale hover:grayscale-0 transition-all duration-300">
              <Image
                src="/images/partner-5.png"
                alt="Socio 5"
                width={128}
                height={48}
                className="w-full h-full object-contain"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="section-title mb-6">Nuestros Servicios</h2>
            <p className="text-lg text-muted-foreground">
              Brindamos soluciones digitales completas para tu negocio, desde la creación de páginas web hasta la
              gestión de redes sociales.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Páginas Web */}
            <div className="card-item bg-card rounded-xl p-6 border shadow-sm hover:shadow-md transition-shadow flex flex-col">
              <Monitor className="h-10 w-10 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-3">Páginas Web</h3>
              <p className="text-muted-foreground mb-6 flex-grow flex items-center">
                Diseñamos páginas web profesionales y responsivas que representan perfectamente tu marca y conectan con
                tu audiencia.
              </p>
              <Link href="/paginas-web">
                <Button variant="buq" size="buq" className="w-full">
                  Contratar
                </Button>
              </Link>
            </div>

            {/* E-Commerce */}
            <div className="card-item bg-card rounded-xl p-6 border shadow-sm hover:shadow-md transition-shadow flex flex-col">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-10 w-10 text-primary mb-4"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="8" cy="21" r="1" />
                <circle cx="19" cy="21" r="1" />
                <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
              </svg>
              <h3 className="text-xl font-bold mb-3">E-Commerce</h3>
              <p className="text-muted-foreground mb-6 flex-grow flex items-center">
                Crea tu tienda online y comienza a vender tus productos a nivel global con plataformas de e-commerce
                completas y seguras.
              </p>
              <Link href="/e-commerce">
                <Button variant="buq" size="buq" className="w-full">
                  Contratar
                </Button>
              </Link>
            </div>

            {/* Gestión de Redes Sociales */}
            <div className="card-item bg-card rounded-xl p-6 border shadow-sm hover:shadow-md transition-shadow flex flex-col">
              <Users className="h-10 w-10 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-3">Redes Sociales</h3>
              <p className="text-muted-foreground mb-6 flex-grow flex items-center">
                Aumenta tu presencia digital con nuestra gestión profesional de redes sociales, creando contenido
                atractivo y estratégico.
              </p>
              <Link href="/redes-sociales">
                <Button variant="buq" size="buq" className="w-full">
                  Contratar
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 primary-gradient text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 max-w-2xl mx-auto">
            ¿Listo para transformar tu presencia digital?
          </h2>
          <p className="text-lg mb-8 max-w-3xl mx-auto opacity-90">
            Únete a cientos de empresas que ya han confiado en DAUC para digitalizar su negocio y llevar su presencia
            online al siguiente nivel.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/empezar">
              <Button className="bg-white text-primary hover:bg-white/90" size="buq">
                ¡Empezar Ahora!
              </Button>
            </Link>
            <Link href="/demo">
              <Button className="bg-white/10 backdrop-blur-sm border border-white hover:bg-white/20" size="buq">
                Agendar Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}

