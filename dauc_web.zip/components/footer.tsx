import Link from "next/link"
import { Facebook, Instagram, Linkedin, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-card border-t">
      <div className="container-custom py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2">
            <Link href="/" className="inline-block mb-4">
              <div className="w-24 h-10 flex items-center">
                <span className="dune-text text-2xl">DAUC</span>
              </div>
            </Link>
            <p className="text-muted-foreground mb-6">
              Somos tu socio digital para llevar tu negocio al siguiente nivel. Diseñamos y desarrollamos soluciones
              digitales a medida para impulsar tu presencia online.
            </p>
            <div className="flex space-x-4">
              <Link
                href="https://facebook.com"
                className="bg-secondary w-10 h-10 rounded-full flex items-center justify-center text-foreground hover:text-primary transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </Link>
              <Link
                href="https://twitter.com"
                className="bg-secondary w-10 h-10 rounded-full flex items-center justify-center text-foreground hover:text-primary transition-colors"
              >
                <Twitter className="h-5 w-5" />
              </Link>
              <Link
                href="https://instagram.com"
                className="bg-secondary w-10 h-10 rounded-full flex items-center justify-center text-foreground hover:text-primary transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </Link>
              <Link
                href="https://linkedin.com"
                className="bg-secondary w-10 h-10 rounded-full flex items-center justify-center text-foreground hover:text-primary transition-colors"
              >
                <Linkedin className="h-5 w-5" />
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Servicios</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/paginas-web" className="text-muted-foreground hover:text-primary transition-colors">
                  Páginas Web
                </Link>
              </li>
              <li>
                <Link href="/e-commerce" className="text-muted-foreground hover:text-primary transition-colors">
                  E-Commerce
                </Link>
              </li>
              <li>
                <Link href="/apps" className="text-muted-foreground hover:text-primary transition-colors">
                  Aplicaciones
                </Link>
              </li>
              <li>
                <Link href="/redes-sociales" className="text-muted-foreground hover:text-primary transition-colors">
                  Redes Sociales
                </Link>
              </li>
              <li>
                <Link href="/seo" className="text-muted-foreground hover:text-primary transition-colors">
                  SEO
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Recursos</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/noticias" className="text-muted-foreground hover:text-primary transition-colors">
                  Noticias
                </Link>
              </li>
              <li>
                <Link href="/tips" className="text-muted-foreground hover:text-primary transition-colors">
                  Tips
                </Link>
              </li>
              <li>
                <Link href="/guias" className="text-muted-foreground hover:text-primary transition-colors">
                  Guías
                </Link>
              </li>
              <li>
                <Link href="/casos-exito" className="text-muted-foreground hover:text-primary transition-colors">
                  Casos de Éxito
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Empresa</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/nosotros" className="text-muted-foreground hover:text-primary transition-colors">
                  Nosotros
                </Link>
              </li>
              <li>
                <Link href="/contacto" className="text-muted-foreground hover:text-primary transition-colors">
                  Contacto
                </Link>
              </li>
              <li>
                <Link href="/precios" className="text-muted-foreground hover:text-primary transition-colors">
                  Precios
                </Link>
              </li>
              <li>
                <Link href="/soporte" className="text-muted-foreground hover:text-primary transition-colors">
                  Soporte
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground mb-4 md:mb-0">
              © {new Date().getFullYear()} <span className="text-primary font-semibold">DAUC</span>. Todos los derechos
              reservados.
            </p>
            <div className="flex space-x-6">
              <Link href="/privacidad" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Política de Privacidad
              </Link>
              <Link href="/terminos" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Términos de Servicio
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

