import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function BlogPage() {
  const blogPosts = [
    {
      id: 1,
      title: "Cómo mejorar la presencia digital de tu negocio",
      excerpt:
        "Descubre estrategias efectivas para aumentar la visibilidad online de tu empresa y llegar a más clientes potenciales.",
      date: "10 Febrero, 2024",
      author: "María González",
      category: "Marketing Digital",
      image: "/placeholder.svg?height=400&width=600",
      slug: "como-mejorar-presencia-digital",
    },
    {
      id: 2,
      title: "7 tendencias de e-commerce para este año",
      excerpt:
        "Conoce las tendencias más importantes en comercio electrónico que debes implementar para mantenerte competitivo.",
      date: "25 Enero, 2024",
      author: "Carlos Ramírez",
      category: "E-Commerce",
      image: "/placeholder.svg?height=400&width=600",
      slug: "tendencias-ecommerce-este-anio",
    },
    {
      id: 3,
      title: "Guía para optimizar la velocidad de tu sitio web",
      excerpt:
        "Aprende a mejorar la velocidad de carga de tu sitio web para ofrecer una mejor experiencia de usuario y mejorar tu SEO.",
      date: "15 Enero, 2024",
      author: "Ana Martínez",
      category: "Desarrollo Web",
      image: "/placeholder.svg?height=400&width=600",
      slug: "guia-optimizar-velocidad-sitio-web",
    },
    {
      id: 4,
      title: "Cómo crear una estrategia de contenido eficaz",
      excerpt:
        "Descubre los pasos para desarrollar una estrategia de contenido que conecte con tu audiencia y genere resultados.",
      date: "5 Enero, 2024",
      author: "Pablo Sánchez",
      category: "Marketing de Contenidos",
      image: "/placeholder.svg?height=400&width=600",
      slug: "como-crear-estrategia-contenido-eficaz",
    },
    {
      id: 5,
      title: "Los mejores plugins para tu tienda WooCommerce",
      excerpt:
        "Conoce los plugins esenciales que te ayudarán a mejorar y potenciar tu tienda online basada en WooCommerce.",
      date: "20 Diciembre, 2023",
      author: "Luis Gómez",
      category: "E-Commerce",
      image: "/placeholder.svg?height=400&width=600",
      slug: "mejores-plugins-tienda-woocommerce",
    },
    {
      id: 6,
      title: "Guía completa de SEO para principiantes",
      excerpt:
        "Todo lo que necesitas saber para comenzar a optimizar tu sitio web para los motores de búsqueda y aumentar tu visibilidad.",
      date: "10 Diciembre, 2023",
      author: "Elena Torres",
      category: "SEO",
      image: "/placeholder.svg?height=400&width=600",
      slug: "guia-completa-seo-principiantes",
    },
  ]

  return (
    <>
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-background to-secondary/30">
        <div className="container-custom text-center">
          <h1 className="section-title mb-6">Blog de Buq</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-10">
            Recursos, guías y consejos para potenciar tu presencia digital y hacer crecer tu negocio online
          </p>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-16">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <article
                key={post.id}
                className="bg-card rounded-xl overflow-hidden border shadow-sm hover:shadow-md transition-shadow"
              >
                <Link href={`/blog/${post.slug}`} className="block">
                  <div className="relative h-48 overflow-hidden">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      width={600}
                      height={400}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                    <div className="absolute top-4 left-4 bg-primary text-white text-xs font-bold py-1 px-2 rounded">
                      {post.category}
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="flex items-center text-sm text-muted-foreground mb-3">
                      <span>{post.date}</span>
                      <span className="mx-2">•</span>
                      <span>Por {post.author}</span>
                    </div>

                    <h2 className="text-xl font-bold mb-3 hover:text-primary transition-colors">{post.title}</h2>
                    <p className="text-muted-foreground mb-4">{post.excerpt}</p>

                    <Button variant="link" className="p-0 font-semibold text-primary">
                      Leer artículo
                    </Button>
                  </div>
                </Link>
              </article>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button variant="outline" size="lg">
              Cargar más artículos
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-secondary/30">
        <div className="container-custom max-w-4xl">
          <div className="bg-card rounded-xl p-8 md:p-12 border shadow-sm">
            <div className="text-center mb-8">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">Suscríbete a nuestro newsletter</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Recibe las últimas noticias, recursos y consejos directamente en tu bandeja de entrada
              </p>
            </div>

            <form className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
              <input
                type="email"
                placeholder="Tu correo electrónico"
                className="flex h-12 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                required
              />
              <Button variant="buq" size="buq" type="submit">
                Suscribirme
              </Button>
            </form>
          </div>
        </div>
      </section>
    </>
  )
}

