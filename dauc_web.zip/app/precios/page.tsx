export default function PreciosPage() {
  return (
    <section className="py-24 md:py-32">
      <div className="container-custom">
        <h1 className="section-title text-center mb-12">Nuestros Precios</h1>
        {/* Add pricing tables or cards here */}
      </div>
    </section>
  )
}

