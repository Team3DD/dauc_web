import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

export default function EcommercePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-background to-secondary/30">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="section-title mb-6">Potencia tu negocio con E-Commerce</h1>
              <p className="text-xl text-muted-foreground mb-8">
                Lanza tu tienda online con DAUC y comienza a vender en cualquier parte del mundo. Soluciones
                personalizadas para cada tipo de negocio.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/contacto">
                  <Button variant="buq" size="buq">
                    Solicitar Propuesta
                  </Button>
                </Link>
                <Link href="#caracteristicas">
                  <Button variant="outline" size="buq">
                    Ver Características
                  </Button>
                </Link>
              </div>
            </div>
            <div className="rounded-xl overflow-hidden relative h-[400px]">
              <Image
                src="/placeholder.svg?height=800&width=1200"
                alt="E-Commerce DAUC"
                width={1200}
                height={800}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Características */}
      <section id="caracteristicas" className="py-16 md:py-24">
        <div className="container-custom">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="section-title mb-6">Características de nuestras tiendas online</h2>
            <p className="text-lg text-muted-foreground">
              Creamos tiendas online a medida con todas las funcionalidades que necesitas para vender tus productos
            </p>
          </div>

          <div className="card-container">
            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                  <line x1="8" y1="21" x2="16" y2="21" />
                  <line x1="12" y1="17" x2="12" y2="21" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Diseño Responsive</h3>
              <p className="text-muted-foreground mb-6 flex-grow flex items-center">
                Tu tienda se adaptará perfectamente a cualquier dispositivo, desde smartphones hasta ordenadores de
                escritorio.
              </p>
              <Button variant="buq" size="buq" className="w-full">
                Contratar
              </Button>
            </div>

            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Gestión de Usuarios</h3>
              <p className="text-muted-foreground mb-6 flex-grow flex items-center">
                Sistema completo de registro, login y perfiles de usuarios para mejorar la experiencia de compra.
              </p>
              <Button variant="buq" size="buq" className="w-full">
                Contratar
              </Button>
            </div>

            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
                  <line x1="1" y1="10" x2="23" y2="10" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Pasarela de Pago Stripe</h3>
              <p className="text-muted-foreground mb-6 flex-grow flex items-center">
                Integración con Stripe para procesar pagos de forma segura y eficiente en tu tienda online.
              </p>
              <Button variant="buq" size="buq" className="w-full">
                Contratar
              </Button>
            </div>

            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="16 3 21 3 21 8" />
                  <line x1="4" y1="20" x2="21" y2="3" />
                  <polyline points="21 16 21 21 16 21" />
                  <line x1="15" y1="15" x2="21" y2="21" />
                  <line x1="4" y1="4" x2="9" y2="9" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">SEO Optimizado</h3>
              <p className="text-muted-foreground mb-6 flex-grow flex items-center">
                Tu tienda estará optimizada para los motores de búsqueda, mejorando tu visibilidad online.
              </p>
              <Button variant="buq" size="buq" className="w-full">
                Contratar
              </Button>
            </div>

            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 2a10 10 0 1 0 10 10H12V2z" />
                  <path d="M21.18 8.02A10 10 0 1 0 8.02 21.18L21.18 8.02z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Analítica Avanzada</h3>
              <p className="text-muted-foreground mb-6 flex-grow flex items-center">
                Obtén insights valiosos sobre el comportamiento de tus clientes y el rendimiento de tu tienda.
              </p>
              <Button variant="buq" size="buq" className="w-full">
                Contratar
              </Button>
            </div>

            <div className="card-item bg-card rounded-xl p-6 border shadow-sm flex flex-col">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-primary"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="9" cy="21" r="1" />
                  <circle cx="20" cy="21" r="1" />
                  <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Gestión de Inventario</h3>
              <p className="text-muted-foreground mb-6 flex-grow flex items-center">
                Control completo sobre tu inventario, con alertas de stock y sincronización multicanal.
              </p>
              <Button variant="buq" size="buq" className="w-full">
                Contratar
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Plataformas */}
      <section className="py-16 md:py-24 bg-secondary/30">
        <div className="container-custom">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="section-title mb-6">Plataformas que utilizamos</h2>
            <p className="text-lg text-muted-foreground">
              Trabajamos con las mejores tecnologías para crear tu tienda online
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="bg-transparent rounded-xl p-6 text-center">
              <div className="h-20 flex items-center justify-center mb-4">
                <Image
                  src="/placeholder.svg?height=80&width=160"
                  alt="WooCommerce"
                  width={160}
                  height={80}
                  className="max-h-20 w-auto"
                />
              </div>
              <h3 className="font-semibold">WooCommerce</h3>
            </div>

            <div className="bg-transparent rounded-xl p-6 text-center">
              <div className="h-20 flex items-center justify-center mb-4">
                <Image
                  src="/placeholder.svg?height=80&width=160"
                  alt="Shopify"
                  width={160}
                  height={80}
                  className="max-h-20 w-auto"
                />
              </div>
              <h3 className="font-semibold">Shopify</h3>
            </div>

            <div className="bg-transparent rounded-xl p-6 text-center">
              <div className="h-20 flex items-center justify-center mb-4">
                <Image
                  src="/placeholder.svg?height=80&width=160"
                  alt="PrestaShop"
                  width={160}
                  height={80}
                  className="max-h-20 w-auto"
                />
              </div>
              <h3 className="font-semibold">PrestaShop</h3>
            </div>

            <div className="bg-transparent rounded-xl p-6 text-center">
              <div className="h-20 flex items-center justify-center mb-4">
                <Image
                  src="/placeholder.svg?height=80&width=160"
                  alt="Magento"
                  width={160}
                  height={80}
                  className="max-h-20 w-auto"
                />
              </div>
              <h3 className="font-semibold">Magento</h3>
            </div>
          </div>
        </div>
      </section>

      {/* Precios */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="section-title mb-6">Planes E-Commerce</h2>
            <p className="text-lg text-muted-foreground">Soluciones adaptadas a las necesidades de tu negocio</p>
          </div>

          <div className="card-container">
            {/* Plan Básico */}
            <div className="card-item bg-card rounded-xl border shadow-sm overflow-hidden flex flex-col">
              <div className="p-6 bg-primary/5">
                <h3 className="text-xl font-bold mb-2">Tienda Básica</h3>
                <p className="text-muted-foreground mb-4">Ideal para negocios que empiezan</p>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold">$14,999</span>
                </div>
                <p className="text-sm text-muted-foreground">Pago único</p>
              </div>

              <div className="p-6 flex flex-col flex-grow">
                <ul className="space-y-3 mb-6 flex-grow">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Hasta 100 productos</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Diseño responsive</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Integración con Stripe</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Gestión básica de inventario</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Soporte por 1 mes</span>
                  </li>
                </ul>

                <Link href="/contacto?plan=ecommerce-basico" className="block">
                  <Button variant="buq" size="buq" className="w-full">
                    Contratar
                  </Button>
                </Link>
              </div>
            </div>

            {/* Plan Profesional */}
            <div className="card-item bg-card rounded-xl border shadow-lg overflow-hidden relative flex flex-col">
              <div className="absolute top-5 right-5 bg-primary text-white text-xs font-bold py-1 px-3 rounded-full">
                Recomendado
              </div>

              <div className="p-6 bg-primary/10">
                <h3 className="text-xl font-bold mb-2">Tienda Profesional</h3>
                <p className="text-muted-foreground mb-4">Para negocios en crecimiento</p>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold">$24,999</span>
                </div>
                <p className="text-sm text-muted-foreground">Pago único</p>
              </div>

              <div className="p-6 flex flex-col flex-grow">
                <ul className="space-y-3 mb-6 flex-grow">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Hasta 500 productos</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Diseño personalizado</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Integración completa con Stripe</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Gestión avanzada de inventario</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Integración con redes sociales</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Soporte por 3 meses</span>
                  </li>
                </ul>

                <Link href="/contacto?plan=ecommerce-profesional" className="block">
                  <Button variant="buq" size="buq" className="w-full">
                    Contratar
                  </Button>
                </Link>
              </div>
            </div>

            {/* Plan Premium */}
            <div className="card-item bg-card rounded-xl border shadow-sm overflow-hidden flex flex-col">
              <div className="p-6 bg-primary/5">
                <h3 className="text-xl font-bold mb-2">Tienda Premium</h3>
                <p className="text-muted-foreground mb-4">Solución completa para empresas</p>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold">$39,999</span>
                </div>
                <p className="text-sm text-muted-foreground">Pago único</p>
              </div>

              <div className="p-6 flex flex-col flex-grow">
                <ul className="space-y-3 mb-6 flex-grow">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Productos ilimitados</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Diseño premium a medida</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Integración avanzada con Stripe</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Sistema completo de inventario</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Integración con ERPs</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Múltiples idiomas y monedas</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0" />
                    <span>Soporte por 6 meses</span>
                  </li>
                </ul>

                <Link href="/contacto?plan=ecommerce-premium" className="block">
                  <Button variant="buq" size="buq" className="w-full">
                    Contratar
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 max-w-2xl mx-auto">
            ¿Listo para llevar tu negocio al siguiente nivel?
          </h2>
          <p className="text-lg mb-8 max-w-3xl mx-auto opacity-90">
            Contáctanos hoy mismo y comienza a vender tus productos online. Nuestro equipo te asesorará para encontrar
            la mejor solución para tu negocio.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/contacto">
              <Button className="bg-white text-primary hover:bg-white/90" size="buq">
                Solicitar Propuesta
              </Button>
            </Link>
            <Link href="/demo">
              <Button className="bg-white/10 backdrop-blur-sm border border-white hover:bg-white/20" size="buq">
                Agendar Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}

